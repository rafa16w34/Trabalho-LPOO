import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;

public class Exame {

    static class InfoExame {
        int diasEntrega;
        boolean precisaPreparo;

        InfoExame(int diasEntrega, boolean precisaPreparo) {
            this.diasEntrega = diasEntrega;
            this.precisaPreparo = precisaPreparo;
        }

        public int getDiasEntrega() {
            return diasEntrega;
        }

        public boolean  isPrecisaPreparo() {
            return precisaPreparo;
        }

    }

    private String nome;
    private String tipo;
    private LocalDate dataColeta;

    public static final Map<String, InfoExame> exames = new HashMap<>();
    static {
        exames.put("Hemograma", new InfoExame(2, false));
        exames.put("Raio-X", new InfoExame(5, false));
        exames.put("Urina", new InfoExame(3, false));
        exames.put("Colonoscopia", new InfoExame(7, true));
        exames.put("Covid", new InfoExame(1, false));
        exames.put("Glicose", new InfoExame(2, false));
    }

    public Exame(String nome, String tipo, LocalDate dataColeta) {
        this.nome = nome;
        this.tipo = tipo;
        this.dataColeta = dataColeta;
    }

    public String getNome() {
        return nome;
    }

    public String getTipo() {
        return tipo;
    }

    public LocalDate getDataColeta() {
        return dataColeta;
    }

    public static InfoExame getInfoExame(String nome) {
        return exames.get(nome);
    }

}
import java.time.format.DateTimeFormatter;

public class ExameController {

    private ExameService exameService = new ExameService();

    public void mostrarInformacoes(Exame exame) {
        System.out.println("\n=== INFORMAÇÕES DO EXAME ===");
        System.out.println("Nome: " + exame.getNome());
        System.out.println("Tipo: " + exame.getTipo());

        var dataEntrega = exameService.calcularDataDeEntrega(exame);

        if (dataEntrega != null) {
            System.out.println("Data de entrega: " +
                    dataEntrega.format(DateTimeFormatter.ofPattern("dd/MM/yyyy")));
        }

        boolean preparo = exameService.precisaDePreparo(exame);

        if (preparo) {
            System.out.println("O exame requer preparo previo!!");
        }
        else{
            System.out.println("O exame nao requer preparo previo!!");
        }

    }
}
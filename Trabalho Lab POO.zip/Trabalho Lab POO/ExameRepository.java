import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class ExameRepository {

    private List<Exame> exames = new ArrayList<>();

    //adicionando um novo exame
    public void salvar(Exame exame){
        exames.add(exame);
        System.out.println("Exame salvo com sucesso: "+ exame.getNome() );
    }

    //listando os exames existentes com cadastro
    public List<Exame> listarTodos() {
        return exames;
    }

    public Optional<Exame> buscarPorNome(String nome){
        return exames.stream()
                .filter(e -> e.getNome().equalsIgnoreCase(nome))
                .findFirst();
    }

    // Remove um exame pelo nome
    public boolean removerPorNome(String nome) {
        Optional<Exame> exame = buscarPorNome(nome);
        if (exame.isPresent()) {
            exames.remove(exame.get());
            System.out.println(" Exame removido: " + nome);
            return true;
        }
        System.out.println(" Exame não encontrado: " + nome);
        return false;
    }

    // Atualiza o tipo ou dados do exame (exemplo simples)
    public boolean atualizar(Exame exameAntigo, Exame exameNovo) {
        int index = exames.indexOf(exameAntigo);
        if (index != -1) {
            exames.set(index, exameNovo);
            System.out.println("Exame atualizado: " + exameNovo.getNome());
            return true;
        }
        System.out.println(" Exame não encontrado para atualização!");
        return false;
    }
}
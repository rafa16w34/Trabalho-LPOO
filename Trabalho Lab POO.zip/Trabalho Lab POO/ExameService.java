import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

public class ExameService {

    private ExameRepository exameRepository = new ExameRepository();

    // Calcula a data de entrega com base no tipo do exame
    public LocalDate calcularDataDeEntrega(Exame exame) {
        Exame.InfoExame info = Exame.getInfoExame(exame.getNome());
        if (info != null) {
            return exame.getDataColeta().plusDays(info.getDiasEntrega());
        } else {
            System.out.println("Exame \"" + exame.getNome() + "\" não encontrado.");
            return null;
        }
    }

    // Salva novo exame
    public void salvarExame(Exame exame) {
        exameRepository.salvar(exame);
    }

    // Lista todos os exames
    public List<Exame> listarExames() {
        return exameRepository.listarTodos();
    }

    // Busca exame por nome
    public Optional<Exame> buscarExamePorNome(String nome) {
        return exameRepository.buscarPorNome(nome);
    }

    // Remove exame por nome
    public boolean removerExame(String nome) {
        return exameRepository.removerPorNome(nome);
    }

    // Atualiza exame existente
    public boolean atualizarExame(Exame exameAntigo, Exame exameNovo) {
        return exameRepository.atualizar(exameAntigo, exameNovo);
    }

    // Verifica se o exame precisa de preparo
    public boolean precisaDePreparo(Exame exame) {
        Exame.InfoExame info = Exame.getInfoExame(exame.getNome());
        if (info != null) {
            return info.isPrecisaPreparo();
        } else {
            System.out.println("Exame \"" + exame.getNome() + "\" não encontrado!");
            return false;
        }
    }
}
public class Preço {

    private String nome;
    private Cliente cliente;
    private double precoFixo = 20.0;

    public Preço(String nome, Cliente cliente){
        this.nome =nome;
        this.cliente = cliente;
    }

    public boolean temConvenio() {
        // Garante que o cliente existe e que ele realmente tem convênio
        return cliente != null && cliente.empresa.equalsIgnoreCase("unimed");
    }

    public void aplicarDesconto(){
        double preco = precoFixo;

        if (temConvenio()) {
            preco *= 0.8; // desconto de 20%
            System.out.println("💳 Convênio \"" + cliente.empresa + "\" aplicado. Desconto de 20%.");
        } else {
            System.out.println("💰 Sem convênio. Preço normal aplicado.");
        }
        System.out.println("💵 Valor final: R$ " + preco);
    }

}
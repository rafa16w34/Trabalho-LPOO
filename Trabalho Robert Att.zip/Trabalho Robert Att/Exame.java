import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;

public class Exame {

    static class InfoExame {
        int diasEntrega;
        boolean precisaPreparo;

        InfoExame(int diasEntrega, boolean precisaPreparo) {
            this.diasEntrega = diasEntrega;
            this.precisaPreparo = precisaPreparo;
        }
    }

    private String nome;
    private String tipo;
    private Cliente convenio;
    private LocalDate dataColeta;
    private int dias;

    private static final Map<String, InfoExame> exames = new HashMap<>();
    static {
        exames.put("Hemograma", new InfoExame(2, false));
        exames.put("Raio-X", new InfoExame(5, false));
        exames.put("Urina", new InfoExame(3, false));
        exames.put("Colonoscopia", new InfoExame(7, true));
        exames.put("Covid", new InfoExame(1, false));
        exames.put("Glicose", new InfoExame(2, false));
    }

    public Exame(String nome, String tipo, Cliente convenio, LocalDate dataColeta) {
        this.nome = nome;
        this.tipo = tipo;
        this.convenio = convenio;
        this.dataColeta = dataColeta;
    }

    public LocalDate dataDeEntrega() {
        InfoExame info = exames.get(nome);
        if (info != null) {
            return dataColeta.plusDays(info.diasEntrega);
        } else {
            System.out.println("⚠️ Exame \"" + nome + "\" não encontrado.");
            return null;
        }
    }

    public void precisaDePreparo() {
        InfoExame info = exames.get(nome);
        if (info != null) {
            if (info.precisaPreparo)
                System.out.println("🔸 O exame \"" + nome + "\" requer preparo prévio.");
            else
                System.out.println("✅ O exame \"" + nome + "\" não requer preparo.");
        } else {
            System.out.println("⚠️ Exame não encontrado!");
        }
    }

}

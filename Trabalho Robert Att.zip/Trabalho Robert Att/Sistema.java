import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

public class Sistema {

    private static class Agendamento {
        String idCliente;
        String idExame;
        LocalDate data;
        LocalTime hora;

        Agendamento(String idCliente, String idExame, LocalDate data, LocalTime hora) {
            this.idCliente = idCliente;
            this.idExame = idExame;
            this.data = data;
            this.hora = hora;
        }

        void exibirDetalhes() {
            System.out.println("Cliente: " + idCliente +
                    " | Exame: " + idExame +
                    " | Data: " + data +
                    " | Hora: " + hora);
        }
    }

    private List<Agendamento> agendamentos = new ArrayList<>();

    public void adicionar(String idCliente, String idExame, LocalDate data, LocalTime hora) {
        agendamentos.add(new Agendamento(idCliente, idExame, data, hora));
        System.out.println("✅ Agendamento adicionado!");
    }

    public void listarTodos() {
        System.out.println("\n📋 Lista de Agendamentos:");
        for (Agendamento a : agendamentos) {
            a.exibirDetalhes();
        }
    }

    public void remover(String idCliente) {
        agendamentos.removeIf(a -> a.idCliente.equalsIgnoreCase(idCliente));
        System.out.println("🗑️ Agendamento do cliente " + idCliente + " removido!");
    }
}
